// Listing Spark — interactions (no dependencies)
(function () {
  // Mobile menu
  var toggle = document.querySelector('.nav__toggle');
  var menu = document.getElementById('mobile-menu');
  if (toggle && menu) {
    toggle.addEventListener('click', function () {
      var open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      menu.hidden = open;
    });
    menu.addEventListener('click', function (e) {
      if (e.target.closest('a')) { menu.hidden = true; toggle.setAttribute('aria-expanded', 'false'); }
    });
  }

  // Before/after compare sliders
  document.querySelectorAll('[data-compare]').forEach(function (el) {
    var range = el.querySelector('.compare__range');
    var set = function (v) { el.style.setProperty('--pos', v + '%'); };
    range.addEventListener('input', function () { set(range.value); });
  });

  // Gallery: hover (desktop) / tap (touch) shows the original
  document.querySelectorAll('[data-gallery] .tile').forEach(function (tile) {
    var src = tile.getAttribute('data-before');
    if (!src) return;
    var before = new Image();
    before.src = src; before.alt = ''; before.loading = 'lazy';
    before.className = 'tile__before';
    tile.insertBefore(before, tile.querySelector('.tile__label'));
    tile.setAttribute('aria-label', (tile.querySelector('img').alt || 'Photo') + '. Press to show the original.');
    tile.setAttribute('aria-pressed', 'false');
    tile.addEventListener('click', function () {
      var on = tile.classList.toggle('is-on');
      tile.setAttribute('aria-pressed', String(on));
    });
  });

  // Tabs (WAI-ARIA tabs pattern with arrow-key support)
  var tabs = Array.prototype.slice.call(document.querySelectorAll('[role="tab"]'));
  function select(tab) {
    tabs.forEach(function (t) {
      var on = t === tab;
      t.setAttribute('aria-selected', String(on));
      t.tabIndex = on ? 0 : -1;
      document.getElementById(t.getAttribute('aria-controls')).hidden = !on;
    });
  }
  tabs.forEach(function (t, i) {
    t.addEventListener('click', function () { select(t); });
    t.addEventListener('keydown', function (e) {
      var n = null;
      if (e.key === 'ArrowRight') n = tabs[(i + 1) % tabs.length];
      if (e.key === 'ArrowLeft') n = tabs[(i - 1 + tabs.length) % tabs.length];
      if (n) { e.preventDefault(); n.focus(); select(n); }
    });
  });

  // Reveal on scroll
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var targets = document.querySelectorAll('.section__head, .step, .card, .promise, .price-card, .tile, .faq__list');
  if (!reduce && 'IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -8% 0px' });
    targets.forEach(function (t) { t.classList.add('reveal'); io.observe(t); });
  }

  // Footer year
  var y = document.querySelector('[data-year]');
  if (y) y.textContent = new Date().getFullYear();
})();
